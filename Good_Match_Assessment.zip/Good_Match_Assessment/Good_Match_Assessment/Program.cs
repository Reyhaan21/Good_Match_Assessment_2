﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace Good_Match_Assessment
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                string[] csvLines = System.IO.File.ReadAllLines(@"MatchInput.csv");

                var maleList = new List<string>();
                var femaleList = new List<string>();
                List<Players> matchesList = new List<Players>();

                for (int i = 0; i < csvLines.Length; i++)
                {
                    string[] rowData = csvLines[i].Split(';');

                    if (rowData[1] == "m")
                    {
                        maleList.Add(rowData[0]);
                    }
                    else
                    {
                        femaleList.Add(rowData[0]);
                    }
                }

                maleList = maleList.Distinct().ToList();
                femaleList = femaleList.Distinct().ToList();
                bool checkAlphabets = true;
                foreach (var male in maleList)
                {
                    foreach (var female in femaleList)
                    {
                        Players players = new Players();
                        players.players = male + " matches " + female;
                        if (IsAlphabets(players.players) == false)
                        {
                            checkAlphabets = false;
                        }
                        players.match = Convert.ToInt32(getMatch(male, female));
                        matchesList.Add(players);
                    }
                }

                if (checkAlphabets == true)
                {
                    matchesList.Sort();
                    Console.WriteLine(displayMatches(matchesList));
                    WriteToTextFile(displayMatches(matchesList));
                }
                else
                {
                    Console.WriteLine("Invalid input in the data, Please ensure correct data entry");
                }
                Console.ReadLine();
            }
            catch (Exception)
            {
                Console.WriteLine("Error calculating matches");
                Console.ReadLine(); 
            }
            
        }

        public static string getMatch(string male, string female)
        {
            string str, output = "";
            str = (male + " matches " + female).ToUpper();
            str = str.Replace(" ", "");
            int len = str.Length;

            for (int i = 0; i < len; i++)
            {
                int c = 0;
                if (str[i] != '*')
                {
                    for (int j = i; j < len; j++)
                    {
                        if (str[i] == str[j])
                        {
                            c++;
                        }
                    }
                    output += c.ToString();
                    str = str.Replace(str[i], '*');
                }
            }
           
            string s = output;
            bool flag = false;
            while (flag == false)
            {                
                if (s.Length == 2)
                {
                    flag = true;
                }
                else
                {
                    s = reduceString(s);
                }
            }
            return s;
        }

        private static bool IsAlphabets(string inputString)
        {
            Regex r = new Regex("^[a-zA-Z ]+$");
            if (r.IsMatch(inputString))
                return true;
            else
                return false;
        }
        private static string reduceString(string st)
        {
            int l = st.Length;
            int j = l - 1;
            string output = "";
            if ((l % 2) == 0)
            {
                for (int i = 0; i < (l / 2); i++)
                {
                    output += (Convert.ToInt32(st[i].ToString()) + Convert.ToInt32(st[j].ToString())).ToString();
                    j--;
                }
            }
            else
            {
                for (int i = 0; i < ((l - 1) / 2); i++)
                {                    
                    output += (Convert.ToInt32(st[i].ToString()) + Convert.ToInt32(st[j].ToString())).ToString();
                    j--;
                }
                output += st[((l - 1) / 2)];
            }
            return output;
        }

        public static string displayMatches(List<Players> matches)
        {
            string sStr = "";
            foreach (Players s in matches)
            {
                sStr += s.showMatches() + "\n";
            }
            return sStr;
        }

        public static void WriteToTextFile(string str)
        {
             File.WriteAllText("output.txt", str);
        }
    }
}
