﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Good_Match_Assessment
{
    class Players : IComparable
    {
        public string players;
        public int match;

        public Players(string sPlayers, int iMatch)
        {
            players = sPlayers;
            match = iMatch;
        }

        public Players()
        {

        }
        public string showMatches()
        {
            if (match > 80)
                return players + " " + match.ToString() + "%, good match";
            else
                return players + " " + match.ToString() + "%";

        }
        public int CompareTo(object o)
        {
            Players temp = (Players)o;
            if (this.match < temp.match)
                return 1;
            else
                return -1;
        }

    }
}
